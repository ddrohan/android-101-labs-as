package ie.app.models;

/**
 * Created by ddrohan on 22/10/2015.
 */
public class Donation
{
    public String _id;
    public int    amount;
    public String paymenttype;
    public int    upvotes;
    public double latitude;
    public double longitude;

    public Donation (int amount, String method, int upvotes, double lat, double lng)
    {
        this.amount = amount;
        this.paymenttype = method;
        this.upvotes = upvotes;
        this.latitude = lat;
        this.longitude = lng;
    }

    public Donation ()
    {
        this.amount = 0;
        this.paymenttype = "";
        this.upvotes = 0;
        this.latitude = 0.0;
        this.longitude = 0.0;
    }

    public String toString()
    {
        return _id + ", " + amount + ", " + paymenttype + ", " + upvotes + ", " + latitude + ", " + longitude;
    }
}